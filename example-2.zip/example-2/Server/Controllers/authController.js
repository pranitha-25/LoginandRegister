

const User=require('../Models/user')
const {hashPassword,comparePassword}=require('../helpers/auth');

const jwt=require('jsonwebtoken');

const test=(req,resp)=>{
    resp.json('test is working')
}


//register EndPoint
const registerUser=async (req,resp)=>{
    try{
        const {name,email,password}=req.body;
        //Check if name was entered
        if(!name){
            return resp.json({
                error:'name is required'
            })
        };
        if(!password || password.length<6){
            return resp.json({
                error:'Password is required and should be atleast 6 characters long'
            })
        };
        //check email
        const exist=await User.findOne({email});
        if(exist){
            return resp.json({
                error:"Email is taken already"
            })
        }
        const hashedPassword=await hashPassword(password)

        //create user in database
       const user=await User.create({

        name,
        email,
        password:hashedPassword,

       })
       return resp.json(user);
    }catch(error){
        console.log(error);
    }
}

//Login EndPoint

const loginUser=async(req,resp)=>{
    try{
        const {email,password}=req.body;

        //check if user exists
        const user=await User.findOne({email});
        if(!user){
            return resp.json({
                error:"no user found"
            })
        }
        //check if password is matched
        const match=await comparePassword(password,user.password)
        if(match){

            jwt.sign({email:user.email,id:user._id,name:user.name},process.env.JWT_SECRET,{},(err,token)=>{
                if(err) throw err;
                resp.cookie('token',token).json(user)
            })
        }
        if(!match){
            resp.json({
                error:"Passwords do not match"
            })
        }

    }
    catch(err){
        console.log(err)
    }
}

const getProfile=(req,resp)=>{
    const{token}=req.cookies
    if(token){
        jwt.verify(token,process.env.JWT_SECRET,{},(err,user)=>{
            if(err) throw err;
            resp.json(user)
        })
        
    }else{
        resp.json(null)
    }
}

module.exports={
    test,
    registerUser,
    loginUser,
    getProfile
}